#include "control/doubleintger.h"
#include <functional>


Nmpc::Nmpc() {
    
    
    N_ = 20;
    dt_ = 0.01;
    u_max_ = 4;
    w_max_ = 2;
    vector<double> weights = {10,10,1}; //Q,R
    u_min_ = - u_max_;
    w_min_ = - w_max_;
    
    Q_ = DM::zeros(2,2); //索引之前初始化size
    R_ = DM::zeros(1,1);
    

    setWeights(weights);
    kinematic_equation_ = setKinematicEquation();
    std::cout<<kinematic_equation_<<std::endl;
}
Nmpc::~Nmpc() {}

void Nmpc::setWeights(vector<double> weights) {

    cout << "setweights" << endl;
    Q_(0, 0) = weights[0];
    Q_(1, 1) = weights[1];

    R_(0, 0) = weights[4];
    //R_(2, 2) = weights[5];
    cout << "set weight finish" << endl;

}

Function Nmpc::setKinematicEquation() {



    //cout << "set kinematic" << endl;
    MX x = MX::sym("x");
    MX dx = MX::sym("dx");
    // MX y = MX::sym("y");
    MX q = MX::sym("q");
     MX dq = MX::sym("dq");
    
    MX state_vars = MX::vertcat({dq,dx,q,x});

    MX u = MX::sym("u");
  
    // MX w = MX::sym("w");
    // MX control_vars = MX::vertcat({v, w});
    MX fenmu = I*(M+m)+m*l*l*(M+m*sin(q)*sin(q));


    MX ddx = ((I+m*l*l)*(u + m*l*dq*dq*sin(q))-g*m*m*l*l*sin(q)*cos(q))/(I*(M+m)+m*l*l*(M+m*sin(q)*sin(q)));


    // ddx = ddx/fenmu;

    MX ddq = -m*l*(u*cos(q)+m*l*dq*dq*sin(q)*cos(q)-(M+m)*sin(q))/(I*(M+m)+m*l*l*(M+m*sin(q)*sin(q)));

    //rhs means right hand side
    MX rhs = MX::vertcat({ddq, ddx, dq,dx});
    std::cout<<rhs<<std::endl;;

//    DM atest = DM::zeros(4);
//     atest(0) = 1;

    Function f=    Function("ftest", {dq,dx,q,dx, u}, {ddq,ddx});


   DMDict arg;
    arg["dq"] = 1.0; // 请替换为实际值
    arg["dx"] = 2.0; // 请替换为实际值
    arg["q"] = 0.5;  // 请替换为实际值
    arg["x"] = 1.0;  // 请替换为实际值
    arg["u"] = 3.0;  // 请替换为实际值

    // 调用函数并获取结果
    DMDict result = f(arg);
    // DM OUT = f(atest,0);
    std::cout<<result<<std::endl;

    return Function("kinematic_equation", {state_vars, u}, {ddq,ddx,dq,dx});


    auto dx = MX::sym("dx");
    auto x = MX::sym("x");

    auto u = MX::sym("u");
    // auto ddx = MX::sym("ddx");
    

    auto rhs = vercat({u,dx });
    return Function("kinematic_equation", {dx,x, u}, {rhs});


}

bool Nmpc::solve(Eigen::Vector4d current_states, Eigen::MatrixXd desired_states) {
    
    cout << " solveWDRRERRRRRRRRRRRREWRWER" << endl;
    Opti opti = Opti();
    //这样？
    Slice all;

    MX cost = 0;
    X = opti.variable(4, N_ + 1);
    U = opti.variable(1, N_);


    MX X_ref = opti.parameter(4, N_ + 1);
    MX X_cur = opti.parameter(4);
    DM x_tmp1 = {current_states[0], current_states[1], current_states[2],current_states[3]};

   std::cout<< opti.debug()<<std::endl;

    opti.set_value(X_cur, x_tmp1);  //set current state
    cout << "set current state success" << endl;

    

    X_ref = MX::zeros(4,N_+1);
    // reshape(X_ref_d, 4, N_ + 1);
    

    //set costfunction
    for (int i = 0; i < N_; ++i) {
        MX X_err = X(all, i) - X_ref(all, i); 
        MX U_0 = U(all, i);
        //cout << "U_0 size:" << U_0.size() << endl;
        //cout << "cost size:" << cost_.size() << endl;
        cost += MX::mtimes({X_err.T(), Q_, X_err});
        //cout << "cost size:" << cost_.size() << endl; 
        cost += MX::mtimes({U_0.T(), R_, U_0});
        //cout << "cost size:" << cost_.size() << endl;
    }

    //cout << "cost size:" << cost_.size() << endl;
    cost += MX::mtimes({(X(all, N_) - X_ref(all, N_)).T(), Q_,
                        X(all, N_) - X_ref(all, N_)});
    //cout << "cost:" << cost << endl;

    opti.minimize(cost);
    //cout << "set cost success" << endl;

    //kinematic constrains
    for (int i = 0; i < N_; ++i) {
      std::vector< MX> input(2);
        input[0] = X(all, i);
        input[1] = U(all, i);
        MX X_next = kinematic_equation_(input)[0] * dt_ + X(all, i);
        std::cout<<kinematic_equation_(input)[0]<<std::endl;
        opti.subject_to(X_next == X(all, i + 1));
    }

//     //init value
//     opti.subject_to(X(all, 0) == X_cur);

//     //speed angle_speed limit
    

//     opti.subject_to(0 <= U <= u_max_);
//     // opti.subject_to(w_min_ <= w <= w_max_);

//     //set solver
//     casadi::Dict solver_opts;
//     solver_opts["expand"] = true; //MX change to SX for speed up
//     solver_opts["ipopt.max_iter"] = 100;
//     solver_opts["ipopt.print_level"] = 0;
//     solver_opts["print_time"] = 0;
//     solver_opts["ipopt.acceptable_tol"] = 1e-6;
//     solver_opts["ipopt.acceptable_obj_change_tol"] = 1e-6;

//     opti.solver("ipopt", solver_opts);

//     //auto sol = opti.solve();
//     solution_ = std::make_unique<casadi::OptiSol>(opti.solve());

//     return true;
}
vector<double> Nmpc::getFirstU() {
    vector<double> res;
    auto first_v =  solution_->value(U)(0, 0);

    return res;
}

vector<double> Nmpc::getPredictX() {
    vector<double> res;
    auto predict_x = solution_->value(X);
    cout << "nomal" << endl;
    //cout << "predict_x size :" << predict_x.size() << endl;
    for (int i = 0; i <= N_; ++i) {
        res.push_back(static_cast<double>(predict_x(0, i)));
        res.push_back(static_cast<double>(predict_x(1, i)));
                res.push_back(static_cast<double>(predict_x(2, i)));
        res.push_back(static_cast<double>(predict_x(3, i)));

    }
    return res;
}
